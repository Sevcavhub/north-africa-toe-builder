#!/usr/bin/env python3
"""
Phase 9 Scenario Matchmaker

Purpose: Generate balanced Axis vs Allied scenarios with complete Phase 9 structure
- Pairs forces by quarter, points, and experience
- Creates canonical battle_scenarios/ folder structure
- Generates 7 JSON files per PROJECT_SCOPE.md

Output Structure:
battle_scenarios/
  ├── {quarter}_{axis_unit}_vs_{allied_unit}_{size}/
  │   ├── oob_ground.json        # Both forces with TO&E tables
  │   ├── supply_state.json      # Fuel/ammo/water for both sides
  │   ├── weather.json           # Temperature, terrain, season
  │   ├── map_data.json          # Terrain features, deployment zones
  │   ├── victory_conditions.json # Objectives, scoring
  │   ├── oob_air.json           # Placeholder (Phase 8)
  │   └── air_support.json       # Placeholder (Phase 8)
"""

import sys
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import json
from datetime import datetime
from collections import defaultdict

# Add parent directories to path
sys.path.append(str(Path(__file__).parent))
sys.path.append(str(Path(__file__).parent.parent))

# Import BattleGroup slicer for force generation
from battlegroup_scenario_slicer import BattleGroupScenarioSlicer


class ScenarioMatchmaker:
    """
    Intelligent matchmaking for balanced Axis vs Allied scenarios
    """

    # Scenario size configs (from BattleGroup but universally applicable)
    SCENARIO_SIZES = ['squad', 'platoon', 'company', 'battalion']

    POINTS_TARGETS = {
        'squad': 250,
        'platoon': 500,
        'company': 1000,
        'battalion': 1500
    }

    # Nation alignments
    AXIS_NATIONS = ['german', 'italian']
    ALLIED_NATIONS = ['british', 'american', 'french']

    # Experience level equivalents for matching
    EXPERIENCE_TIERS = {
        'elite': 4,
        'veteran': 3,
        'regular': 2,
        'inexperienced': 1
    }

    def __init__(self, project_root: Path = None):
        """Initialize matchmaker"""
        if project_root is None:
            project_root = Path(__file__).parent.parent.parent

        self.project_root = project_root
        self.units_dir = project_root / 'data' / 'output' / 'units'
        self.output_dir = project_root / 'data' / 'output' / 'battle_scenarios'
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.slicer = BattleGroupScenarioSlicer()

        # Cache of available forces by quarter
        self.forces_by_quarter = defaultdict(lambda: {'axis': [], 'allied': []})

    def scan_available_forces(self) -> Dict:
        """
        Scan all unit JSONs to build database of available forces

        Returns dict: {quarter: {axis: [...], allied: [...]}}
        """
        print("\n[Phase 9] Scanning available forces...")

        unit_files = sorted(self.units_dir.glob('*_toe.json'))

        scanned = 0
        skipped = 0

        for unit_file in unit_files:
            try:
                with open(unit_file, 'r', encoding='utf-8') as f:
                    unit_data = json.load(f)

                # Extract metadata
                nation = unit_data.get('nation', 'unknown')
                quarter = unit_data.get('quarter', 'unknown')
                unit_name = unit_data.get('unit_name', unit_file.stem)

                if nation == 'unknown' or quarter == 'unknown':
                    skipped += 1
                    continue

                # Check if unit has equipment data
                has_equipment = False
                for section in ['tanks', 'field_artillery', 'anti_tank', 'artillery']:
                    if section in unit_data and unit_data[section]:
                        has_equipment = True
                        break

                if not has_equipment:
                    skipped += 1
                    continue

                # Filter by organizational level - only match divisions
                org_level = unit_data.get('organization_level', '').lower()
                if org_level not in ['division', 'brigade']:
                    # Skip armies, corps, and other high-level formations
                    # (These create unbalanced matchups - armies have 10x personnel of divisions)
                    skipped += 1
                    continue

                # Classify as Axis or Allied
                alignment = 'axis' if nation in self.AXIS_NATIONS else 'allied'

                # Store force info
                force_info = {
                    'file_path': str(unit_file),
                    'nation': nation,
                    'quarter': quarter,
                    'unit_name': unit_name,
                    'unit_data': unit_data,
                    'organization_level': org_level,
                    'experience': self._extract_experience(unit_data, nation, quarter)
                }

                self.forces_by_quarter[quarter][alignment].append(force_info)
                scanned += 1

            except Exception as e:
                print(f"  [ERROR] Failed to scan {unit_file.name}: {e}")
                skipped += 1

        print(f"  Scanned: {scanned} units")
        print(f"  Skipped: {skipped} units (no equipment or metadata)")
        print(f"  Quarters with forces: {len(self.forces_by_quarter)}")

        return self.forces_by_quarter

    def _extract_experience(self, unit_data: Dict, nation: str, quarter: str) -> str:
        """Extract or estimate experience level"""
        # Check if experience is explicitly in unit data
        if 'experience_level' in unit_data:
            return unit_data['experience_level']

        # Estimate based on nation and quarter
        # Germans: veteran until 1943, then regular
        if nation == 'german':
            if quarter < '1943q1':
                return 'veteran'
            else:
                return 'regular'

        # British: regular early, veteran mid-war
        elif nation == 'british':
            if '1941q3' <= quarter <= '1942q4':
                return 'veteran'
            else:
                return 'regular'

        # Americans: inexperienced 1942q4, regular after
        elif nation == 'american':
            if quarter == '1942q4':
                return 'inexperienced'
            else:
                return 'regular'

        # Italians: regular
        elif nation == 'italian':
            return 'regular'

        return 'regular'  # Default

    def generate_matchups(self, max_per_quarter: int = 10) -> List[Dict]:
        """
        Generate balanced Axis vs Allied matchups

        Args:
            max_per_quarter: Maximum scenarios per quarter (prevents explosion)

        Returns:
            List of matchup dicts with axis_force, allied_force, scenario_size
        """
        print("\n[Phase 9] Generating matchups...")

        matchups = []

        for quarter in sorted(self.forces_by_quarter.keys()):
            quarter_data = self.forces_by_quarter[quarter]
            axis_forces = quarter_data['axis']
            allied_forces = quarter_data['allied']

            if not axis_forces or not allied_forces:
                print(f"  [SKIP] {quarter}: Missing {'Axis' if not axis_forces else 'Allied'} forces")
                continue

            print(f"\n  {quarter}: {len(axis_forces)} Axis, {len(allied_forces)} Allied")

            # Generate matchups for each scenario size
            quarter_matchups = []

            for scenario_size in self.SCENARIO_SIZES:
                # Try to pair each Axis force with best Allied match
                for axis_force in axis_forces:
                    best_match = self._find_best_match(
                        axis_force,
                        allied_forces,
                        scenario_size
                    )

                    if best_match:
                        matchup = {
                            'quarter': quarter,
                            'scenario_size': scenario_size,
                            'axis_force': axis_force,
                            'allied_force': best_match,
                            'points_target': self.POINTS_TARGETS[scenario_size]
                        }
                        quarter_matchups.append(matchup)

                # Limit matchups per quarter per size
                if len(quarter_matchups) > max_per_quarter:
                    quarter_matchups = quarter_matchups[:max_per_quarter]

            matchups.extend(quarter_matchups)
            print(f"    Generated {len(quarter_matchups)} matchups")

        print(f"\n  Total matchups: {len(matchups)}")
        return matchups

    def _find_best_match(self, axis_force: Dict, allied_forces: List[Dict],
                         scenario_size: str) -> Optional[Dict]:
        """
        Find best Allied force to match against Axis force

        Scoring based on:
        - Experience similarity (prefer veteran vs veteran)
        - Force type similarity (armor vs armor, infantry vs infantry)
        - Historical plausibility
        """
        best_match = None
        best_score = -1

        axis_exp_tier = self.EXPERIENCE_TIERS.get(axis_force['experience'], 2)

        for allied_force in allied_forces:
            allied_exp_tier = self.EXPERIENCE_TIERS.get(allied_force['experience'], 2)

            score = 100  # Base score

            # Organizational level matching (CRITICAL - prevents army vs division)
            axis_org = axis_force.get('organization_level', 'division')
            allied_org = allied_force.get('organization_level', 'division')

            if axis_org == allied_org:
                score += 50  # Same level (division vs division, brigade vs brigade)
            else:
                # Mismatched levels are unacceptable (army vs division creates 10:1 imbalance)
                score -= 1000  # Effectively disqualify this matchup

            # Personnel ratio matching (CRITICAL - prevents 3:1 imbalances)
            axis_personnel = axis_force['unit_data'].get('total_personnel', 0)
            allied_personnel = allied_force['unit_data'].get('total_personnel', 0)

            # Safely convert to int (handles dict/None/invalid values)
            try:
                axis_personnel = int(axis_personnel) if axis_personnel else 0
            except (TypeError, ValueError):
                axis_personnel = 0

            try:
                allied_personnel = int(allied_personnel) if allied_personnel else 0
            except (TypeError, ValueError):
                allied_personnel = 0

            if axis_personnel > 0 and allied_personnel > 0:
                # Calculate ratio (higher / lower)
                if axis_personnel > allied_personnel:
                    ratio = axis_personnel / allied_personnel
                else:
                    ratio = allied_personnel / axis_personnel

                # Score based on ratio quality
                if ratio <= 1.5:
                    score += 40  # Excellent balance (within 1.5:1)
                elif ratio <= 2.0:
                    score += 20  # Acceptable balance (within 2:1)
                elif ratio <= 2.5:
                    score -= 30  # Poor balance (2-2.5:1)
                else:
                    score -= 100  # Very imbalanced (>2.5:1) - heavily penalize

            # Experience matching (±1 tier is acceptable)
            exp_diff = abs(axis_exp_tier - allied_exp_tier)
            if exp_diff == 0:
                score += 30  # Perfect match
            elif exp_diff == 1:
                score += 15  # Close match
            else:
                score -= 20  # Poor match

            # Force type matching (check if both have tanks, etc.)
            axis_has_tanks = 'tank' in axis_force['unit_name'].lower() or \
                           'panzer' in axis_force['unit_name'].lower() or \
                           'armour' in axis_force['unit_name'].lower()

            allied_has_tanks = 'tank' in allied_force['unit_name'].lower() or \
                             'panzer' in allied_force['unit_name'].lower() or \
                             'armour' in allied_force['unit_name'].lower()

            if axis_has_tanks == allied_has_tanks:
                score += 20  # Similar force composition

            # Historical plausibility (prefer British vs German/Italian, American vs German in 1943)
            if axis_force['nation'] == 'german' and allied_force['nation'] == 'british':
                score += 10
            elif axis_force['nation'] == 'italian' and allied_force['nation'] == 'british':
                score += 10
            elif axis_force['nation'] == 'german' and allied_force['nation'] == 'american' and \
                 axis_force['quarter'] >= '1942q4':
                score += 10

            if score > best_score:
                best_score = score
                best_match = allied_force

        return best_match

    def generate_scenario(self, matchup: Dict) -> Optional[str]:
        """
        Generate complete Phase 9 scenario with all 7 JSON files

        Returns scenario directory path if successful
        """
        try:
            # Create scenario directory
            scenario_name = self._generate_scenario_name(matchup)
            scenario_dir = self.output_dir / scenario_name
            scenario_dir.mkdir(parents=True, exist_ok=True)

            # Generate each required file
            self._generate_oob_ground(matchup, scenario_dir)
            self._generate_supply_state(matchup, scenario_dir)
            self._generate_weather(matchup, scenario_dir)
            self._generate_map_data(matchup, scenario_dir)
            self._generate_victory_conditions(matchup, scenario_dir)
            self._generate_air_placeholders(matchup, scenario_dir)

            return str(scenario_dir)

        except Exception as e:
            print(f"    [ERROR] {scenario_name}: {e}")
            return None

    def _generate_scenario_name(self, matchup: Dict) -> str:
        """Generate scenario directory name"""
        quarter = matchup['quarter']
        size = matchup['scenario_size']

        axis_name = matchup['axis_force']['unit_name'].lower().replace(' ', '_')[:30]
        allied_name = matchup['allied_force']['unit_name'].lower().replace(' ', '_')[:30]

        return f"{quarter}_{axis_name}_vs_{allied_name}_{size}"

    def _generate_oob_ground(self, matchup: Dict, scenario_dir: Path):
        """Generate oob_ground.json with both forces and TO&E tables (sliced to scenario size)"""
        # This will use data from the unit JSONs directly
        axis_unit = matchup['axis_force']['unit_data']
        allied_unit = matchup['allied_force']['unit_data']
        scenario_size = matchup['scenario_size']

        # Extract full TOE and summaries
        axis_toe_full = self._extract_toe_table(axis_unit)
        allied_toe_full = self._extract_toe_table(allied_unit)
        axis_summary_full = self._extract_equipment_summary(axis_unit)
        allied_summary_full = self._extract_equipment_summary(allied_unit)

        # Slice forces to appropriate size for BattleGroup
        axis_toe_sliced = self._slice_toe_to_scenario_size(axis_toe_full, scenario_size)
        allied_toe_sliced = self._slice_toe_to_scenario_size(allied_toe_full, scenario_size)

        # Recalculate summaries from sliced TOE (ensure they match)
        axis_summary_sliced = self._calculate_summary_from_toe(axis_toe_sliced, axis_summary_full, scenario_size)
        allied_summary_sliced = self._calculate_summary_from_toe(allied_toe_sliced, allied_summary_full, scenario_size)

        oob = {
            'scenario_name': scenario_dir.name,
            'quarter': matchup['quarter'],
            'scenario_size': matchup['scenario_size'],
            'points_target': matchup['points_target'],
            'generated_at': datetime.now().isoformat(),

            'axis_force': {
                'nation': matchup['axis_force']['nation'],
                'unit_name': matchup['axis_force']['unit_name'],
                'experience': matchup['axis_force']['experience'],
                'toe': axis_toe_sliced,
                'equipment_summary': axis_summary_sliced
            },

            'allied_force': {
                'nation': matchup['allied_force']['nation'],
                'unit_name': matchup['allied_force']['unit_name'],
                'experience': matchup['allied_force']['experience'],
                'toe': allied_toe_sliced,
                'equipment_summary': allied_summary_sliced
            }
        }

        output_file = scenario_dir / 'oob_ground.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(oob, f, indent=2, ensure_ascii=False)

    def _slice_toe_to_scenario_size(self, toe: Dict, scenario_size: str) -> Dict:
        """
        Slice TOE to appropriate size for BattleGroup scenarios

        Reduction ratios based on BattleGroup scenarios (from Torch Mission PDF):
        - Squad: 0.5-1.5% of division (~50-150 personnel, 5-9 units)
        - Platoon: 2-4% of division (~200-400 personnel, 10-15 units)
        - Company: 6-10% of division (~600-1000 personnel, 15-25 units)
        - Battalion: 15-25% of division (~1500-2500 personnel, 30-50 units)
        """
        import math

        # Reduction percentages (average of range)
        reduction_ratios = {
            'squad': 0.01,      # 1% of division
            'platoon': 0.03,    # 3% of division
            'company': 0.08,    # 8% of division
            'battalion': 0.20   # 20% of division
        }

        ratio = reduction_ratios.get(scenario_size, 0.01)

        sliced_toe = {
            'tanks': {},
            'artillery': {},
            'anti_tank': {},
            'infantry': {},
            'vehicles': {}
        }

        # Slice each equipment category
        for category in ['tanks', 'artillery', 'anti_tank', 'vehicles']:
            if category in toe:
                for equipment_name, equipment_data in toe[category].items():
                    if isinstance(equipment_data, dict) and 'count' in equipment_data:
                        original_count = equipment_data['count']
                        # Apply reduction and round (minimum 1 if original > 0)
                        sliced_count = max(1, math.ceil(original_count * ratio)) if original_count > 0 else 0

                        if sliced_count > 0:
                            sliced_toe[category][equipment_name] = {
                                **equipment_data,
                                'count': sliced_count
                            }

        # Infantry doesn't get sliced the same way (keep minimal representation)
        if 'infantry' in toe:
            sliced_toe['infantry'] = toe['infantry']

        return sliced_toe

    def _slice_summary_to_scenario_size(self, summary: Dict, scenario_size: str) -> Dict:
        """Slice equipment summary to match scenario size"""
        import math

        reduction_ratios = {
            'squad': 0.01,
            'platoon': 0.03,
            'company': 0.08,
            'battalion': 0.20
        }

        ratio = reduction_ratios.get(scenario_size, 0.01)

        sliced_summary = {}
        for key, value in summary.items():
            if isinstance(value, int):
                # Apply reduction (minimum 1 if original > 0, except for personnel)
                if key == 'total_personnel':
                    sliced_summary[key] = max(50, math.ceil(value * ratio))  # Minimum 50 personnel for squad
                else:
                    sliced_summary[key] = max(1, math.ceil(value * ratio)) if value > 0 else 0
            else:
                sliced_summary[key] = value

        return sliced_summary

    def _calculate_summary_from_toe(self, toe: Dict, original_summary: Dict, scenario_size: str) -> Dict:
        """
        Calculate equipment summary from sliced TOE (ensures TOE and summary match)

        Args:
            toe: Sliced TOE dict
            original_summary: Original full division summary (for personnel calculation)
            scenario_size: Scenario size for personnel slicing

        Returns:
            Equipment summary matching the sliced TOE
        """
        import math

        # Count equipment from TOE
        total_tanks = sum(item['count'] for item in toe.get('tanks', {}).values() if isinstance(item, dict))
        total_artillery = sum(item['count'] for item in toe.get('artillery', {}).values() if isinstance(item, dict))
        total_at_guns = sum(item['count'] for item in toe.get('anti_tank', {}).values() if isinstance(item, dict))

        # Slice personnel proportionally
        reduction_ratios = {
            'squad': 0.01,
            'platoon': 0.03,
            'company': 0.08,
            'battalion': 0.20
        }
        ratio = reduction_ratios.get(scenario_size, 0.01)
        original_personnel = original_summary.get('total_personnel', 10000)
        total_personnel = max(50, math.ceil(original_personnel * ratio))

        return {
            'total_tanks': total_tanks,
            'total_artillery': total_artillery,
            'total_at_guns': total_at_guns,
            'total_personnel': total_personnel
        }

    def _extract_toe_table(self, unit_data: Dict) -> Dict:
        """Extract TO&E table from unit JSON (supports schema v3.0.0 and v3.1.0)"""
        toe = {
            'tanks': {},
            'artillery': {},
            'anti_tank': {},
            'infantry': {},
            'vehicles': {}
        }

        schema_version = unit_data.get('schema_version', '3.0.0')

        # Extract tanks (both schemas)
        if 'tanks' in unit_data and isinstance(unit_data['tanks'], dict):
            # Try v3.1.0 'breakdown' first, then v3.0.0 'variants'
            equipment = unit_data['tanks'].get('breakdown', unit_data['tanks'].get('variants', {}))
            if equipment:
                for tank_name, data in equipment.items():
                    # Schema v3.1.0: data is int, Schema v3.0.0: data is dict with 'count' key
                    count = data if isinstance(data, int) else (data.get('count', 0) if isinstance(data, dict) else 0)
                    if count > 0:
                        toe['tanks'][tank_name] = {
                            'count': count,
                            'type': 'tank'
                        }

        # Extract field artillery (both schemas)
        if 'field_artillery' in unit_data and isinstance(unit_data['field_artillery'], dict):
            # Try v3.1.0 'breakdown' first, then v3.0.0 'variants'
            equipment = unit_data['field_artillery'].get('breakdown', unit_data['field_artillery'].get('variants', {}))
            if equipment:
                for gun_name, data in equipment.items():
                    # Schema v3.1.0: data is int, Schema v3.0.0: data is dict with 'count' key
                    count = data if isinstance(data, int) else (data.get('count', 0) if isinstance(data, dict) else 0)
                    if count > 0:
                        # Caliber from v3.0.0 dict or extract from name
                        caliber = data.get('caliber', self._extract_caliber_from_name(gun_name)) if isinstance(data, dict) else self._extract_caliber_from_name(gun_name)
                        toe['artillery'][gun_name] = {
                            'count': count,
                            'caliber': caliber
                        }

        # Extract AT guns (schema v3.1.0 uses 'anti_tank_guns', v3.0.0 uses 'anti_tank')
        at_section = 'anti_tank_guns' if schema_version >= '3.1.0' else 'anti_tank'
        if at_section in unit_data and isinstance(unit_data[at_section], dict):
            # Try v3.1.0 'breakdown' first, then v3.0.0 'variants'
            equipment = unit_data[at_section].get('breakdown', unit_data[at_section].get('variants', {}))
            if equipment:
                for gun_name, data in equipment.items():
                    # Schema v3.1.0: data is int, Schema v3.0.0: data is dict with 'count' key
                    count = data if isinstance(data, int) else (data.get('count', 0) if isinstance(data, dict) else 0)
                    if count > 0:
                        # Caliber from v3.0.0 dict or extract from name
                        caliber = data.get('caliber', self._extract_caliber_from_name(gun_name)) if isinstance(data, dict) else self._extract_caliber_from_name(gun_name)
                        toe['anti_tank'][gun_name] = {
                            'count': count,
                            'caliber': caliber
                        }

        # Also check the other AT field name as fallback
        alt_at_section = 'anti_tank' if at_section == 'anti_tank_guns' else 'anti_tank_guns'
        if not toe['anti_tank'] and alt_at_section in unit_data and isinstance(unit_data[alt_at_section], dict):
            equipment = unit_data[alt_at_section].get('breakdown', unit_data[alt_at_section].get('variants', {}))
            if equipment:
                for gun_name, data in equipment.items():
                    # Schema v3.1.0: data is int, Schema v3.0.0: data is dict with 'count' key
                    count = data if isinstance(data, int) else (data.get('count', 0) if isinstance(data, dict) else 0)
                    if count > 0:
                        # Caliber from v3.0.0 dict or extract from name
                        caliber = data.get('caliber', self._extract_caliber_from_name(gun_name)) if isinstance(data, dict) else self._extract_caliber_from_name(gun_name)
                        toe['anti_tank'][gun_name] = {
                            'count': count,
                            'caliber': caliber
                        }

        # Extract vehicles (both schemas)
        if 'trucks_and_lorries' in unit_data and isinstance(unit_data['trucks_and_lorries'], dict):
            equipment = unit_data['trucks_and_lorries'].get('breakdown', unit_data['trucks_and_lorries'].get('variants', {}))
            if equipment:
                for vehicle_name, data in equipment.items():
                    # Schema v3.1.0: data is int, Schema v3.0.0: data is dict with 'count' key
                    count = data if isinstance(data, int) else (data.get('count', 0) if isinstance(data, dict) else 0)
                    if count > 0:
                        toe['vehicles'][vehicle_name] = {
                            'count': count,
                            'type': 'transport'
                        }

        return toe

    def _extract_caliber_from_name(self, gun_name: str) -> str:
        """Extract caliber from gun name (e.g., '75/27 Mod. 1911' -> '75mm')"""
        import re
        # Match patterns like "75/27", "105/28", "QF 25-pounder" (87.6mm), etc.
        match = re.search(r'(\d+)[/-]', gun_name)
        if match:
            return f"{match.group(1)}mm"
        # Special case for British QF 25-pounder
        if '25-pounder' in gun_name or '25 pounder' in gun_name:
            return '87.6mm'
        if '2-pounder' in gun_name or '2 pounder' in gun_name:
            return '40mm'
        if '6-pounder' in gun_name or '6 pounder' in gun_name:
            return '57mm'
        if '17-pounder' in gun_name or '17 pounder' in gun_name:
            return '76.2mm'
        return 'unknown'

    def _extract_equipment_summary(self, unit_data: Dict) -> Dict:
        """Extract equipment summary counts (supports schema v3.0.0 and v3.1.0)"""
        summary = {
            'total_tanks': 0,
            'total_artillery': 0,
            'total_at_guns': 0,
            'total_personnel': unit_data.get('total_personnel', 0) or 0
        }

        # Safely extract personnel (handle dict/None/invalid values)
        try:
            summary['total_personnel'] = int(summary['total_personnel']) if summary['total_personnel'] else 0
        except (TypeError, ValueError):
            summary['total_personnel'] = 0

        schema_version = unit_data.get('schema_version', '3.0.0')

        # Count tanks (both schemas use same structure)
        if 'tanks' in unit_data:
            if isinstance(unit_data['tanks'], dict):
                summary['total_tanks'] = unit_data['tanks'].get('total', 0) or 0

        # Count artillery (field_artillery in both schemas)
        if 'field_artillery' in unit_data and isinstance(unit_data['field_artillery'], dict):
            total = unit_data['field_artillery'].get('total', 0)
            summary['total_artillery'] = total if total is not None else 0

        # Count AT guns (schema v3.1.0 uses 'anti_tank_guns', v3.0.0 uses 'anti_tank')
        at_section = 'anti_tank_guns' if schema_version >= '3.1.0' else 'anti_tank'
        if at_section in unit_data and isinstance(unit_data[at_section], dict):
            summary['total_at_guns'] = unit_data[at_section].get('total', 0) or 0

        # Fallback to alternative AT section name
        alt_at_section = 'anti_tank' if at_section == 'anti_tank_guns' else 'anti_tank_guns'
        if summary['total_at_guns'] == 0 and alt_at_section in unit_data and isinstance(unit_data[alt_at_section], dict):
            summary['total_at_guns'] = unit_data[alt_at_section].get('total', 0) or 0

        return summary

    def _generate_supply_state(self, matchup: Dict, scenario_dir: Path):
        """Generate supply_state.json"""
        axis_unit = matchup['axis_force']['unit_data']
        allied_unit = matchup['allied_force']['unit_data']

        supply_state = {
            'quarter': matchup['quarter'],

            'axis_supply': self._extract_supply_data(axis_unit, matchup['axis_force']['nation']),
            'allied_supply': self._extract_supply_data(allied_unit, matchup['allied_force']['nation'])
        }

        output_file = scenario_dir / 'supply_state.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(supply_state, f, indent=2, ensure_ascii=False)

    def _extract_supply_data(self, unit_data: Dict, nation: str) -> Dict:
        """Extract supply logistics from unit JSON"""
        supply_logistics = unit_data.get('supply_logistics', {})

        return {
            'fuel_days': supply_logistics.get('fuel_days', 7),
            'ammunition_days': supply_logistics.get('ammunition_days', 7),
            'water_days': supply_logistics.get('water_days', 7),
            'operational_radius_km': supply_logistics.get('operational_radius_km', 200),
            'supply_status': supply_logistics.get('supply_status', 'adequate'),
            'notes': supply_logistics.get('notes', 'Standard operational supply levels')
        }

    def _generate_weather(self, matchup: Dict, scenario_dir: Path):
        """Generate weather.json"""
        # Extract from unit data if available
        axis_unit = matchup['axis_force']['unit_data']
        weather_env = axis_unit.get('weather_environment', {})

        quarter = matchup['quarter']
        season = self._determine_season(quarter)

        weather = {
            'quarter': quarter,
            'season': season,
            'terrain_type': weather_env.get('terrain_type', 'Desert - sparse cover, open sightlines'),
            'temperature_range_celsius': weather_env.get('temperature_range_celsius', [25, 45]),
            'seasonal_impacts': weather_env.get('seasonal_impacts', [
                'Extreme heat during day',
                'Dust storms reduce visibility',
                'Clear skies favor air operations'
            ]),
            'environmental_challenges': weather_env.get('environmental_challenges', [
                'Water scarcity',
                'Engine overheating',
                'Sand damage to equipment'
            ]),
            'visibility_km': 10,
            'precipitation': 'none',
            'wind_speed_kph': 15
        }

        output_file = scenario_dir / 'weather.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(weather, f, indent=2, ensure_ascii=False)

    def _determine_season(self, quarter: str) -> str:
        """Determine season from quarter"""
        q = quarter.split('q')[1] if 'q' in quarter else '1'
        seasons = {'1': 'Winter', '2': 'Spring', '3': 'Summer', '4': 'Autumn'}
        return seasons.get(q, 'Summer')

    def _generate_map_data(self, matchup: Dict, scenario_dir: Path):
        """Generate map_data.json"""
        size = matchup['scenario_size']

        # Table sizes based on scenario size
        table_sizes = {
            'squad': {'width_cm': 120, 'length_cm': 120},  # 4'x4'
            'platoon': {'width_cm': 120, 'length_cm': 180},  # 4'x6'
            'company': {'width_cm': 180, 'length_cm': 240},  # 6'x8'
            'battalion': {'width_cm': 240, 'length_cm': 360}  # 8'x12'
        }

        map_data = {
            'scenario_size': size,
            'table_dimensions': table_sizes.get(size, table_sizes['platoon']),
            'terrain_features': [
                {'type': 'hill', 'position': 'center', 'elevation_m': 50},
                {'type': 'wadi', 'position': 'left_flank', 'depth_m': 3},
                {'type': 'rocky_outcrop', 'position': 'right_flank', 'size': 'small'},
                {'type': 'sparse_vegetation', 'coverage': '10%'}
            ],
            'deployment_zones': {
                'axis': {
                    'edge': 'north',
                    'depth_cm': 30,
                    'description': 'Axis forces deploy within 30cm of north table edge'
                },
                'allied': {
                    'edge': 'south',
                    'depth_cm': 30,
                    'description': 'Allied forces deploy within 30cm of south table edge'
                }
            },
            'objectives': [
                {'type': 'capture_point', 'location': 'center_hill', 'points': 3},
                {'type': 'capture_point', 'location': 'left_wadi', 'points': 2},
                {'type': 'capture_point', 'location': 'right_outcrop', 'points': 2}
            ]
        }

        output_file = scenario_dir / 'map_data.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(map_data, f, indent=2, ensure_ascii=False)

    def _generate_victory_conditions(self, matchup: Dict, scenario_dir: Path):
        """Generate victory_conditions.json"""
        victory = {
            'scenario_type': 'meeting_engagement',
            'primary_victory': {
                'type': 'break_enemy_force',
                'description': 'Force enemy to withdraw by exceeding their break point',
                'scoring': 'First side to exceed break point loses'
            },
            'secondary_objectives': [
                {
                    'type': 'capture_objectives',
                    'description': 'Control 2 of 3 objectives at game end',
                    'points': 3
                },
                {
                    'type': 'destroy_enemy_command',
                    'description': 'Destroy or route enemy command unit',
                    'points': 2
                },
                {
                    'type': 'minimize_casualties',
                    'description': 'Take fewer casualties than opponent',
                    'points': 1
                }
            ],
            'turn_limit': self._determine_turn_limit(matchup['scenario_size']),
            'sudden_death': 'Game ends immediately when one side breaks',
            'draw_conditions': 'Both sides break simultaneously or neither breaks by turn limit'
        }

        output_file = scenario_dir / 'victory_conditions.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(victory, f, indent=2, ensure_ascii=False)

    def _determine_turn_limit(self, size: str) -> int:
        """Determine turn limit based on scenario size"""
        limits = {
            'squad': 6,
            'platoon': 8,
            'company': 10,
            'battalion': 12
        }
        return limits.get(size, 8)

    def _generate_air_placeholders(self, matchup: Dict, scenario_dir: Path):
        """Generate placeholder files for Phase 8 (Air Forces)"""
        # oob_air.json placeholder
        oob_air = {
            'status': 'Phase 8 not yet implemented',
            'note': 'Air order of battle will be populated after Phase 8 air forces integration',
            'quarter': matchup['quarter'],
            'axis_air': {
                'available': False,
                'units': []
            },
            'allied_air': {
                'available': False,
                'units': []
            }
        }

        output_file = scenario_dir / 'oob_air.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(oob_air, f, indent=2, ensure_ascii=False)

        # air_support.json placeholder
        air_support = {
            'status': 'Phase 8 not yet implemented',
            'note': 'Air support data (sortie rates, aircraft availability) will be populated after Phase 8',
            'quarter': matchup['quarter'],
            'axis_sortie_rate': 0,
            'allied_sortie_rate': 0
        }

        output_file = scenario_dir / 'air_support.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(air_support, f, indent=2, ensure_ascii=False)


def main():
    """Generate Phase 9 battle scenarios"""
    print("\n" + "="*80)
    print("Phase 9 Scenario Matchmaker")
    print("="*80)

    matchmaker = ScenarioMatchmaker()

    # Step 1: Scan available forces
    matchmaker.scan_available_forces()

    # Step 2: Generate matchups
    matchups = matchmaker.generate_matchups(max_per_quarter=5)  # Limit for initial test

    if not matchups:
        print("\n[ERROR] No matchups generated. Check available forces.")
        return

    # Step 3: Generate scenarios
    print(f"\n[Phase 9] Generating {len(matchups)} scenarios...")

    results = {
        'generated': 0,
        'failed': 0,
        'scenarios': []
    }

    for matchup in matchups:
        scenario_name = matchmaker._generate_scenario_name(matchup)
        print(f"\n  Generating: {scenario_name}")

        scenario_dir = matchmaker.generate_scenario(matchup)

        if scenario_dir:
            results['generated'] += 1
            results['scenarios'].append(scenario_dir)
            print(f"    [OK] Created {scenario_dir}")
        else:
            results['failed'] += 1

    # Summary
    print(f"\n{'='*80}")
    print(f"Phase 9 Scenario Generation Complete")
    print(f"{'='*80}")
    print(f"  Scenarios generated: {results['generated']}")
    print(f"  Failed: {results['failed']}")
    print(f"  Output directory: data/output/battle_scenarios/")
    print(f"{'='*80}\n")

    return results


if __name__ == '__main__':
    main()
