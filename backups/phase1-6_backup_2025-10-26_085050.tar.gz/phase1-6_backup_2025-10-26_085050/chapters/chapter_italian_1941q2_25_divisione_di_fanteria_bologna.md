# 25ª Divisione di Fanteria 'Bologna'

**Nation:** Italian
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Mario Marghinotti

## Personnel

Total: 10650

---
*Generated automatically from TO&E data*
