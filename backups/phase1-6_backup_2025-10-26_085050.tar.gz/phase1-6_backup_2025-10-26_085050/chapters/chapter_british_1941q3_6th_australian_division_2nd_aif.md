# 6th Australian Division (2nd AIF)

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General Major-General Iven Mackay

## Personnel

Total: 16000

---
*Generated automatically from TO&E data*
