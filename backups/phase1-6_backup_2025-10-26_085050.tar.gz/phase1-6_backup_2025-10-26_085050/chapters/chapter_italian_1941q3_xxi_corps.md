# XXI Corpo d'Armata

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** corps

## Command

**Commander:** Generale di Corpo d'Armata Enea Navarini

## Personnel

- **Total:** 40,500
- **Officers:** 2,025
- **NCOs:** 6,075
- **Enlisted:** 32,400

## Tanks

- **Total:** 0
- **Heavy:** [object Object]
- **Medium:** [object Object]
- **Light:** [object Object]

## Artillery

**Total:** 156

## Vehicles

**Total:** 1,285

## Subordinate Units

### 27ª Divisione di Fanteria Brescia
**Commander:**  Generale di Divisione Francesco La Ferla
**Strength:** 13,500 personnel

### 17ª Divisione di Fanteria Pavia
**Commander:**  Generale di Divisione Silvio Franceschini
**Strength:** 13,000 personnel

### 25ª Divisione di Fanteria Bologna
**Commander:**  Generale di Divisione Alessandro Gloria
**Strength:** 13,500 personnel

## Data Quality

- **Confidence:** 77%
- **Completeness:** 82%
- **Schema:** 100
