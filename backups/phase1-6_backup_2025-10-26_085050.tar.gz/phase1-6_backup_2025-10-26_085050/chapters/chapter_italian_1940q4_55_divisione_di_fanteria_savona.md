# 55ª Divisione di Fanteria "Savona"

**Nation:** Italian
**Quarter:** 1940-Q4
**Organization Level:** division

## Commander

Generale di Divisione Pietro Maggiani

## Personnel

Total: 12169

---
*Generated automatically from TO&E data*
