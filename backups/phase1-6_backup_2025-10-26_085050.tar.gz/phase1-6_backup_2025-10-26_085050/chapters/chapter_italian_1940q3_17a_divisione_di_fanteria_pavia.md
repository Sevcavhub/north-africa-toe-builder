# 17a Divisione di Fanteria "Pavia"

**Nation:** Italian
**Quarter:** 1940-Q3
**Organization Level:** division

## Commander

Generale di Divisione Pietro Zaglio

## Personnel

Total: 7500

---
*Generated automatically from TO&E data*
