# 51st (Highland) Infantry Division

**Nation:** British
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Major-General Major-General Douglas Neil Wimberley

## Personnel

Total: 17850

---
*Generated automatically from TO&E data*
