# 1st Armoured Division

**Nation:** British
**Quarter:** 1942-Q1
**Organization Level:** division

## Command

**Commander:** Major-General Major-General Herbert Lumsden

## Personnel

- **Total:** 14,820
- **Officers:** 892
- **NCOs:** 2,150
- **Enlisted:** 11,778

## Tanks

- **Total:** 105
- **Heavy:** [object Object]
- **Medium:** [object Object]
- **Light:** [object Object]

## Artillery

**Total:** 72

## Vehicles

**Total:** 1,842

## Data Quality

- **Confidence:** undefined%
- **Completeness:** N/A%
