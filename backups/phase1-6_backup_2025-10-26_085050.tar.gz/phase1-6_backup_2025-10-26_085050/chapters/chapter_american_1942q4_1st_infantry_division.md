# 1st Infantry Division

**Nation:** American
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Major General Major General Terry de la Mesa Allen Sr.

## Personnel

Total: 15514

---
*Generated automatically from TO&E data*
