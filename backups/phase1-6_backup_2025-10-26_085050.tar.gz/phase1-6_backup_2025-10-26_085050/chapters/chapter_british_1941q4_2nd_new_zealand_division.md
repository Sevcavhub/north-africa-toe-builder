# 2nd New Zealand Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Major-General Major-General Bernard Cyril Freyberg

## Personnel

Total: 22000

---
*Generated automatically from TO&E data*
