# 102ª Divisione di Fanteria Motorizzata "Trento"

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Generale di Divisione (Major General) Generale di Divisione Giuseppe De Stefanis

## Personnel

Total: 7800

---
*Generated automatically from TO&E data*
