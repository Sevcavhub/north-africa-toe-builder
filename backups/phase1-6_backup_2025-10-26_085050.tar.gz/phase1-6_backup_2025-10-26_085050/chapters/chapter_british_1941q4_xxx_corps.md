# XXX Corps

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** corps

## Command

**Commander:** Lieutenant-General Lieutenant-General Charles Willoughby Moke Norrie

## Personnel

- **Total:** 36,650

## Tanks

- **Total:** 445

## Artillery

**Total:** 300

## Subordinate Units

- 7th Armoured Division
- 1st South African Infantry Division
- 22nd Guards Brigade
- XXX Corps Troops

