# 6th Australian Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Personnel

- **Total:** 15,800

## Tanks

- **Total:** 0

## Artillery

**Total:** 120

