# 5th Indian Infantry Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Major-General Major-General Ashton Gerard Oswald Mosley Mayne

## Personnel

Total: 15420

---
*Generated automatically from TO&E data*
