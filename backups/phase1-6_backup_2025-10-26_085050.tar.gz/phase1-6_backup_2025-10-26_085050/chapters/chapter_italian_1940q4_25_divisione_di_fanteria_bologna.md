# 25ª Divisione di Fanteria 'Bologna'

**Nation:** Italian
**Quarter:** 1940-Q4
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Roberto Lerici

## Personnel

Total: 10978

---
*Generated automatically from TO&E data*
