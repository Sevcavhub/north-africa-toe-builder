# 9th Australian Division

**Nation:** British
**Quarter:** 1942q4
**Organization Level:** division

## Commander

Major-General Leslie Morshead

## Personnel

Total: 16000

---
*Generated automatically from TO&E data*
