# 2nd New Zealand Division

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General Bernard Cyril Freyberg

## Personnel

Total: 20000

---
*Generated automatically from TO&E data*
