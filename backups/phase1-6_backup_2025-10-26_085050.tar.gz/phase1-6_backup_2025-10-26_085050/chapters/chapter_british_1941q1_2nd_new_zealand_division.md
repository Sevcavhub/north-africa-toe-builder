# 2nd New Zealand Division

**Nation:** British
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Major-General Bernard Cyril Freyberg

## Personnel

Total: 17850

---
*Generated automatically from TO&E data*
