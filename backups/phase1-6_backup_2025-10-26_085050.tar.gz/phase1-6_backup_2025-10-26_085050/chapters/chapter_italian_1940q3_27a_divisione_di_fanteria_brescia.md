# 27a Divisione di Fanteria "Brescia"

**Nation:** Italian
**Quarter:** 1940-Q3
**Organization Level:** division

## Commander

Generale di Divisione Giuseppe Cremascoli

## Personnel

Total: 7450

---
*Generated automatically from TO&E data*
