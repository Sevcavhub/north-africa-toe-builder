# 101st TRIESTE Division

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Divisional General Not specified in source

## Personnel

Total: 11800

---
*Generated automatically from TO&E data*
