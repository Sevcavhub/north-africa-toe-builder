# XX Corpo d'Armata (Corpo d'Armata di Manovra)

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** corps

## Command

**Commander:** Generale di Corpo d'Armata Gastone Gambara

## Personnel

- **Total:** 16,939
- **Officers:** 627
- **NCOs:** 1,845
- **Enlisted:** 14,467

## Tanks

- **Total:** 165
- **Heavy:** [object Object]
- **Medium:** [object Object]
- **Light:** [object Object]

## Artillery

**Total:** 84

## Vehicles

**Total:** 2,719

## Subordinate Units

### 132ª Divisione Corazzata "Ariete"
**Commander:**  Generale di Brigata Mario Balotta
**Strength:** 7,439 personnel

### 101ª Divisione Motorizzata "Trieste"
**Commander:**  Generale di Divisione Alessandro Piazzoni
**Strength:** 9,500 personnel

## Data Quality

- **Confidence:** 84%
- **Completeness:** 88%
- **Schema:** 100
