# 1re Brigade Française Libre

**Nation:** French
**Quarter:** 1942-Q2
**Organization Level:** regiment

## Commander

Général de brigade Général de brigade Marie-Pierre Koenig

## Personnel

Total: 3850

---
*Generated automatically from TO&E data*
