# XXX Corps

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** corps

## Command

**Commander:** Lieutenant-General Vyvyan Vavasour Pope

*Appointed GOC XXX Corps August 1941, flew to Egypt September 1941. Assembled staff but killed in air crash at Heliopolis on 5 October 1941 (Q4) before first operation. Succeeded by Lt-Gen Willoughby Norrie.*

## Personnel

- **Total:** 36,650
- **Officers:** 1,520
- **NCOs:** 5,480
- **Enlisted:** 29,650

## Tanks

- **Total:** 172
- **Heavy:** [object Object]
- **Medium:** [object Object]
- **Light:** [object Object]

## Artillery

**Total:** 260

## Vehicles

**Total:** 8,524

## Subordinate Units

### 7th Armoured Division
**Commander:**  Major-General William Henry Ewart Gott
**Strength:** 14,850 personnel

### 1st South African Infantry Division
**Commander:**  Major-General George Edwin Brink
**Strength:** 15,800 personnel

### 22nd Guards Brigade
**Commander:**  Brigadier John Charles Oakes Marriott
**Strength:** 3,800 personnel

### XXX Corps Troops
**Strength:** 2,200 personnel

## Data Quality

- **Confidence:** 80%
- **Completeness:** 78%
- **Schema:** 100
