# XIII Corps

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** corps

## Command

**Commander:** Lieutenant-General Alfred Reade Godwin-Austen

*Succeeded Lt-Gen Beresford-Peirse in August 1941. Previously Western Desert Force, redesignated XIII Corps September 1941.*

## Personnel

- **Total:** 45,000
- **Officers:** 2,100
- **NCOs:** 6,400
- **Enlisted:** 36,500

## Tanks

- **Total:** 130
- **Heavy:** [object Object]
- **Medium:** [object Object]
- **Light:** [object Object]

## Artillery

**Total:** 308

## Vehicles

**Total:** 7,200

## Subordinate Units

### 2nd New Zealand Division
**Commander:**  Major-General Bernard Cyril Freyberg VC
**Strength:** 20,000 personnel

### 4th Indian Infantry Division
**Commander:**  Major-General Frank Messervy
**Strength:** 15,000 personnel

### 1st Army Tank Brigade
**Commander:**  Brigadier Henry Russell Brindley Watkins
**Strength:** 2,200 personnel

### XIII Corps Troops
**Strength:** 7,800 personnel

## Data Quality

- **Confidence:** 78%
- **Completeness:** 82%
- **Schema:** 100
