# 2nd South African Infantry Division

**Nation:** British
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Major-General Isaac Pierre de Villiers

## Personnel

Total: 23850

## Artillery

Total: 120 pieces

---
*Generated from TO&E data*
