# 1st Armoured Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Major-General Major-General Herbert Lumsden

## Personnel

Total: 14200

---
*Generated automatically from TO&E data*
