# 62ª Divisione di Fanteria 'Marmarica'

**Nation:** Italian
**Quarter:** 1940-Q3
**Organization Level:** division

## Command

**Commander:** Generale di Divisione Generale di Divisione Ruggero Tracchia

## Personnel

- **Total:** 12,900
- **Officers:** 645
- **NCOs:** 1,935
- **Enlisted:** 10,320

## Tanks

- **Total:** 0

## Artillery

**Total:** 32

## Vehicles

**Total:** 285

## Data Quality

- **Confidence:** 79%
- **Completeness:** 82%
