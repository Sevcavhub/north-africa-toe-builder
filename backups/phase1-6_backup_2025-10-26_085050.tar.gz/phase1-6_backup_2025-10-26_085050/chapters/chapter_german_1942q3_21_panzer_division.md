# 21. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Generalmajor Generalmajor Georg von Bismarck

## Personnel

Total: 13850

---
*Generated automatically from TO&E data*
