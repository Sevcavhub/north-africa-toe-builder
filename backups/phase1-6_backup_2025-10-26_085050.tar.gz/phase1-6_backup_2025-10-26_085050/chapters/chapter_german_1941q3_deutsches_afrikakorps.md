# Deutsches Afrikakorps (DAK)

**Nation:** German
**Quarter:** 1941-Q3
**Organization Level:** corps

## Commander

Generalleutnant Erwin Rommel

## Personnel

Total: 27400

---
*Generated automatically from TO&E data*
