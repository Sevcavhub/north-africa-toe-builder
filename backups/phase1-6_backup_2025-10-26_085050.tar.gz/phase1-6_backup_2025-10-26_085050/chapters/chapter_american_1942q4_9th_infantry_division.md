# 9th Infantry Division

**Nation:** American
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Major General Manton S. Eddy

## Personnel

Total: 15514

---
*Generated automatically from TO&E data*
