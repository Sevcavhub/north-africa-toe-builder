# 1re Division Française Libre

**Nation:** French
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Général de brigade Pierre Koenig

## Personnel

Total: 9200

---
*Generated automatically from TO&E data*
