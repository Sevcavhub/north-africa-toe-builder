# 132ª Divisione Corazzata "Ariete"

**Nation:** Italian
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Major General Generale di Divisione Francesco Antonio Arena

## Personnel

Total: 6800

---
*Generated automatically from TO&E data*
