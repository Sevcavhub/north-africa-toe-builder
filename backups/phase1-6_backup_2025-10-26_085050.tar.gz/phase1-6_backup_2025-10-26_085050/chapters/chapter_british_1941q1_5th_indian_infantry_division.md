# 5th Indian Infantry Division

**Nation:** British
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Major-General Major-General Lewis Heath

## Personnel

Total: 17000

---
*Generated automatically from TO&E data*
