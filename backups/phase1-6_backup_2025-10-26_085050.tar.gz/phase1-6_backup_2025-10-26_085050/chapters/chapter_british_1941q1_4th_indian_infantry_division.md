# 4th Indian Infantry Division

**Nation:** British
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Major-General Major-General Noel Beresford-Peirse

## Personnel

Total: 15842

---
*Generated automatically from TO&E data*
