# 17ª Divisione di Fanteria 'Pavia'

**Nation:** Italian
**Quarter:** 1940-Q4
**Organization Level:** division

## Commander

Generale di Divisione Pietro Zaglio

## Personnel

Total: 10978

---
*Generated automatically from TO&E data*
