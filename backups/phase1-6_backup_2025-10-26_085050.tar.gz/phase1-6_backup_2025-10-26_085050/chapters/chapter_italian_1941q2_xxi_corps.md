# XXI Corpo d'Armata

**Nation:** Italian
**Quarter:** 1941-Q2
**Organization Level:** corps

## Commander

Unknown Unknown (Interim Command Period)

## Personnel

Total: 38000

---
*Generated automatically from TO&E data*
