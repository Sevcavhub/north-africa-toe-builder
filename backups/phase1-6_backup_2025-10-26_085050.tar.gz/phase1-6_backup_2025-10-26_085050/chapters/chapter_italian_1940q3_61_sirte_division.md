# 61ª Divisione di Fanteria 'Sirte'

**Nation:** Italian
**Quarter:** 1940-Q3
**Organization Level:** division

## Command

**Commander:** Generale di Divisione Unknown

## Personnel

- **Total:** 12,950
- **Officers:** 648
- **NCOs:** 1,943
- **Enlisted:** 10,359

## Tanks

- **Total:** 0

## Artillery

**Total:** 36

## Vehicles

**Total:** 295

## Data Quality

- **Confidence:** 76%
- **Completeness:** 75%
