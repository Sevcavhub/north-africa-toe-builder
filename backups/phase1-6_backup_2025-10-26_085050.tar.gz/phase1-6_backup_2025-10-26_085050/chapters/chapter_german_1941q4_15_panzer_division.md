# 15. Panzer-Division

**Nation:** German
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Generalleutnant Generalleutnant Walter Neumann-Silkow

## Personnel

Total: 10500

---
*Generated automatically from TO&E data*
