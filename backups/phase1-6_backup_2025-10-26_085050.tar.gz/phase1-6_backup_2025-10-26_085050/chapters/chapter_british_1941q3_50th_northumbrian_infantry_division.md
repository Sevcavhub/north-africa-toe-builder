# 50th (Northumbrian) Infantry Division

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General William Horatio Crawford Ramsden

## Personnel

Total: 17380

---
*Generated automatically from TO&E data*
