# 4th Indian Infantry Division

**Nation:** British
**Quarter:** 1940-Q4
**Organization Level:** division

## Commander

Major-General Major-General Noel Beresford-Peirse

## Personnel

Total: 17800

---
*Generated automatically from TO&E data*
