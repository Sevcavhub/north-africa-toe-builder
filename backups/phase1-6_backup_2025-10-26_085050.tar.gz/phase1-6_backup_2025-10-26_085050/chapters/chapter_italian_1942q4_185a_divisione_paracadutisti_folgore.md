# 185a Divisione Paracadutisti FOLGORE

**Nation:** Italian
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Generale di Brigata Generale Enrico Frattini

## Personnel

Total: 5200

---
*Generated automatically from TO&E data*
