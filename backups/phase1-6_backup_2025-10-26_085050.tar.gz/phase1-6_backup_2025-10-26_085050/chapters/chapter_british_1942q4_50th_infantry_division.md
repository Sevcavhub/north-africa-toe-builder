# 50th (Northumbrian) Infantry Division

**Nation:** British
**Quarter:** 1942q4
**Organization Level:** division

## Commander

Major-General John Nichols

## Personnel

Total: 15500

---
*Generated automatically from TO&E data*
