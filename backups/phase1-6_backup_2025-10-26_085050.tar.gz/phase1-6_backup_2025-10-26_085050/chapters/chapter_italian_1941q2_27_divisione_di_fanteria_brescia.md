# 27ª Divisione di fanteria "Brescia"

**Nation:** Italian
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Brigadier General (Generale di Brigata) Generale di Brigata Bortolo Zambon

## Personnel

Total: 12169

---
*Generated automatically from TO&E data*
