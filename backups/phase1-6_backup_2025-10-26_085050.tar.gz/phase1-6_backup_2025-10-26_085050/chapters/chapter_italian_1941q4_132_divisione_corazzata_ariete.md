# 132a Divisione Corazzata "Ariete"

**Nation:** Italian
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Generale di Brigata Mario Balotta

## Personnel

Total: 4850

---
*Generated automatically from TO&E data*
