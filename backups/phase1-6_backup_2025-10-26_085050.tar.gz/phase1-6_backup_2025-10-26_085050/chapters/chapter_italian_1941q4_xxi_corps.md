# XXI Corpo d'Armata

**Nation:** Italian
**Quarter:** 1941-Q4
**Organization Level:** corps

## Command

**Commander:** Generale di Corpo d'Armata Enea Navarini

## Personnel

- **Total:** 33,800

## Tanks

- **Total:** 0

## Artillery

**Total:** 138

## Subordinate Units

- 27ª Divisione di Fanteria Brescia
- 17ª Divisione di Fanteria Pavia
- 25ª Divisione di Fanteria Bologna

