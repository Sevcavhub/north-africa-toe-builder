# 132ª Divisione corazzata "Ariete"

**Nation:** Italian
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Brigadier General Generale di Brigata Francesco Antonio Arena

## Personnel

Total: 7200

---
*Generated automatically from TO&E data*
