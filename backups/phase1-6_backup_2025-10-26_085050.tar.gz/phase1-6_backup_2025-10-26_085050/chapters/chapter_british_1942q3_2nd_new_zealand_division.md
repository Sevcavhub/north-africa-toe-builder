# 2nd New Zealand Division

**Nation:** British
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Lieutenant-General Bernard Cyril Freyberg

## Personnel

Total: 14200

---
*Generated automatically from TO&E data*
