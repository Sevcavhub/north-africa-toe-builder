# Deutsches Afrikakorps

**Nation:** German
**Quarter:** 1942q4
**Organization Level:** corps

## Commander

Generalleutnant Wilhelm Ritter von Thoma

## Personnel

Total: 52000

---
*Generated automatically from TO&E data*
