# 60ª Divisione di Fanteria 'Sabratha'

**Nation:** Italian
**Quarter:** 1940-Q2
**Organization Level:** division

## Command

**Commander:**  Unknown

## Personnel

- **Total:** 12800
- **Officers:** 640
- **NCOs:** 1920
- **Enlisted:** 10240

## Tanks

- **Total:** 0
- **Heavy:** 0
- **Medium:** 0
- **Light:** 0

## Artillery

**Total:** 36

## Vehicles

**Total:** 285

