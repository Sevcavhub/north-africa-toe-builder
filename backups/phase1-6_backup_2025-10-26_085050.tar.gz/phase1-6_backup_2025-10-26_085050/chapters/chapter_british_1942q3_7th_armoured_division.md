# 7th Armoured Division

**Nation:** British
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Major-General Major-General John Harding

## Personnel

Total: 14850

---
*Generated automatically from TO&E data*
