# XIII Corps

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** corps

## Command

**Commander:** Lieutenant-General Alfred Reade Godwin-Austen

## Personnel

- **Total:** 52,000

## Tanks

- **Total:** 78

## Artillery

**Total:** 290

## Subordinate Units

- 2nd New Zealand Division
- 4th Indian Infantry Division
- 1st Army Tank Brigade
- XIII Corps Troops

