# 164. leichte Afrika-Division

**Nation:** German
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Generalmajor Generalmajor Carl-Hans Lungershausen

## Personnel

Total: 8400

---
*Generated automatically from TO&E data*
