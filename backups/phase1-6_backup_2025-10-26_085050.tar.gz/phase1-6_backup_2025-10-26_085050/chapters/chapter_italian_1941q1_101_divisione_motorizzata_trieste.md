# 101ª Divisione motorizzata 'Trieste'

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Francesco La Ferla

## Personnel

Total: 10000

---
*Generated automatically from TO&E data*
