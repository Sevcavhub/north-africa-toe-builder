# 15. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q1
**Organization Level:** division

## Command

**Commander:** Generalmajor Generalmajor Gustav von Vaerst

## Personnel

- **Total:** 11,920
- **Officers:** 595
- **NCOs:** 1,890
- **Enlisted:** 9,435

## Tanks

- **Total:** 86
- **Heavy:** 0
- **Medium:** 71
- **Light:** 15

## Artillery

**Total:** 283

## Vehicles

**Total:** 1,786

## Data Quality

- **Confidence:** undefined%
- **Completeness:** N/A%
