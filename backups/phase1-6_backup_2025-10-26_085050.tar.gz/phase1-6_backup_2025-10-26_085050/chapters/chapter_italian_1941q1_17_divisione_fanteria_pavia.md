# 17ª Divisione Fanteria "Pavia"

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Generale di Divisione Pietro Zaglio

## Personnel

Total: 10864

---
*Generated automatically from TO&E data*
