# 27ª Divisione Autotrasportabile "Brescia"

**Nation:** Italian
**Quarter:** 1942-Q1
**Organization Level:** division

## Commander

Brigadier General (Generale di Brigata) Generale di Brigata Giacomo Lombardi

## Personnel

Total: 11847

---
*Generated automatically from TO&E data*
