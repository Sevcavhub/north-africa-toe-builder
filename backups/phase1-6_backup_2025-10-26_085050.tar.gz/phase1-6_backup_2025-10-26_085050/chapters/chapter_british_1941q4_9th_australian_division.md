# 9th Australian Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Major-General Major-General Leslie James Morshead

## Personnel

Total: 14500

---
*Generated automatically from TO&E data*
