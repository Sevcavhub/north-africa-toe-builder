# Deutsches Afrikakorps (DAK)

**Nation:** German
**Quarter:** 1941-Q2
**Organization Level:** corps

## Commander

Generalleutnant Generalleutnant Erwin Rommel

## Personnel

Total: 31160

---
*Generated automatically from TO&E data*
