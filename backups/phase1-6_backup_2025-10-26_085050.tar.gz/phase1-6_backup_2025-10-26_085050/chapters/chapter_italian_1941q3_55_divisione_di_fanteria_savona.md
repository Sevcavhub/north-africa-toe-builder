# 55ª Divisione di Fanteria "Savona"

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Generale di Divisione Fedele de Giorgis

## Personnel

Total: 9245

---
*Generated automatically from TO&E data*
