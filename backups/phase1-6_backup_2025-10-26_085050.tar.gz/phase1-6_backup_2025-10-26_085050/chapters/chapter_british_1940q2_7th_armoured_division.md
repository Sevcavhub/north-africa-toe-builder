# 7th Armoured Division

**Nation:** British
**Quarter:** 1940-Q2
**Organization Level:** division

## Commander

Major-General Major-General Sir Michael O'Moore Creagh

## Personnel

Total: 10000

---
*Generated automatically from TO&E data*
