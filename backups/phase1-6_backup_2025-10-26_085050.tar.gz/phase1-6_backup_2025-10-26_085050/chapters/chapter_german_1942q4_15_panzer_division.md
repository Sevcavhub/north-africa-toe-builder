# 15. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Generalmajor Generalmajor Gustav von Vaerst

## Personnel

Total: 8920

---
*Generated automatically from TO&E data*
