# Western Desert Force

**Nation:** British
**Quarter:** 1940-Q4
**Organization Level:** corps

## Commander

Lieutenant-General Lieutenant-General Richard Nugent O'Connor

## Personnel

Total: 38050

---
*Generated automatically from TO&E data*
