# 132ª Divisione Corazzata "Ariete"

**Nation:** Italian
**Quarter:** 1940-Q4
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Ettore Baldassarre

## Personnel

Total: 7500

---
*Generated automatically from TO&E data*
