# Western Desert Force

**Nation:** British
**Quarter:** 1940-Q3
**Organization Level:** corps

## Commander

Lieutenant-General Lieutenant-General Richard Nugent O'Connor

## Personnel

Total: 36000

---
*Generated automatically from TO&E data*
