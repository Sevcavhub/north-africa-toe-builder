# 7th Armoured Division

**Nation:** British
**Quarter:** 1940-Q4
**Organization Level:** division

## Commander

Major-General Major-General Michael O'Moore Creagh

## Personnel

Total: 19500

---
*Generated automatically from TO&E data*
