# 1st South African Division

**Nation:** British
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Major-General George Edwin Brink

## Personnel

Total: 18500

---
*Generated automatically from TO&E data*
