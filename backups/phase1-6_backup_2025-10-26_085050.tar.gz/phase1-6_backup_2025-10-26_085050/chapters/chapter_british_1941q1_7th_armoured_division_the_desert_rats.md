# 7th Armoured Division (The Desert Rats)

**Nation:** British
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Major General Michael O'Moore Creagh

## Personnel

Total: 9200

---
*Generated automatically from TO&E data*
