# 2nd New Zealand Division

**Nation:** British
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Major-General Major-General Bernard Cyril Freyberg

## Personnel

Total: 20000

---
*Generated automatically from TO&E data*
