# 132ª Divisione Corazzata 'Ariete'

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Generale di Divisione (Major General) Generale di Divisione Ettore Baldassarre

## Personnel

Total: 6949

---
*Generated automatically from TO&E data*
