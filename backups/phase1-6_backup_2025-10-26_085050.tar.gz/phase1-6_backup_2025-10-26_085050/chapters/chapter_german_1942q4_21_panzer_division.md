# 21. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Generalmajor Generalmajor Georg von Bismarck (KIA 31 August 1942), then Generalmajor Heinz von Randow (18 September 1942 - 21 December 1942)

## Personnel

Total: 12800

---
*Generated automatically from TO&E data*
