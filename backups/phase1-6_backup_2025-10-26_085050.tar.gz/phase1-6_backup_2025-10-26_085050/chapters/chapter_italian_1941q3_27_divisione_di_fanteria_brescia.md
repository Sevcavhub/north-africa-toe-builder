# 27ª Divisione di Fanteria "Brescia"

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Bartolo Zambon

## Personnel

Total: 10845

---
*Generated automatically from TO&E data*
