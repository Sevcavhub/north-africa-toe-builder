# 1re Division Française Libre (1st Free French Division)

**Nation:** French
**Quarter:** 1943-Q1
**Organization Level:** division

## Commander

Général de Division Général de Division Edgard de Larminat

## Personnel

Total: 15200

---
*Generated automatically from TO&E data*
