# 21. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q1
**Organization Level:** division

## Command

**Commander:** Generalmajor Generalmajor Georg von Bismarck

## Personnel

- **Total:** 11,565
- **Officers:** 520
- **NCOs:** 1,735
- **Enlisted:** 9,310

## Tanks

- **Total:** 79
- **Heavy:** [object Object]
- **Medium:** [object Object]
- **Light:** [object Object]

## Artillery

**Total:** 137

## Vehicles

**Total:** 2,095

## Data Quality

- **Confidence:** undefined%
- **Completeness:** N/A%
