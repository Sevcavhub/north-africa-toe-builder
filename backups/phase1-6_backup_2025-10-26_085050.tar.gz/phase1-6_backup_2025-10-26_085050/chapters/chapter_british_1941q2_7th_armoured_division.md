# 7th Armoured Division

**Nation:** British
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Major-General Major-General Michael O'Moore Creagh

## Personnel

Total: 14964

---
*Generated automatically from TO&E data*
