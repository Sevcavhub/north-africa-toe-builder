# 4th Indian Infantry Division

**Nation:** British
**Quarter:** 1940-Q2
**Organization Level:** division

## Commander

Major-General Major-General Philip Neame

## Personnel

Total: 15000

---
*Generated automatically from TO&E data*
