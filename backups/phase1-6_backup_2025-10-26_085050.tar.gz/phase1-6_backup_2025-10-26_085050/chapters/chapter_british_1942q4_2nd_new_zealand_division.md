# 2nd New Zealand Division

**Nation:** British
**Quarter:** 1942q4
**Organization Level:** division

## Commander

Lieutenant-General Bernard Cyril Freyberg

## Personnel

Total: 16500

---
*Generated automatically from TO&E data*
