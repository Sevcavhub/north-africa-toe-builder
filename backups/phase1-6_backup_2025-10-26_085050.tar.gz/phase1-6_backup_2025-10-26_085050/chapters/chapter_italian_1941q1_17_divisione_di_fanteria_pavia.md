# 17ª Divisione di Fanteria "Pavia"

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Maggiore Generale Pietro Zaglio

## Personnel

Total: 12500

---
*Generated automatically from TO&E data*
