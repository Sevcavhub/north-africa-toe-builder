# 2nd South African Infantry Division

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General Major-General Isaac Pierre de Villiers

## Personnel

Total: 17250

---
*Generated automatically from TO&E data*
