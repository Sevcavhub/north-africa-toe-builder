# 9th Australian Division

**Nation:** British
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Lieutenant-General Lieutenant-General Leslie James Morshead

## Personnel

Total: 14250

---
*Generated automatically from TO&E data*
