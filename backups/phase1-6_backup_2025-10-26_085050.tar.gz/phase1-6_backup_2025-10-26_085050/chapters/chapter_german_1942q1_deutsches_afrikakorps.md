# Deutsches Afrikakorps (DAK)

**Nation:** German
**Quarter:** 1942-Q1
**Organization Level:** corps

## Command

**Commander:** Generalleutnant Generalleutnant Ludwig Crüwell

## Personnel

- **Total:** 23,850

## Tanks

- **Total:** 165

## Artillery

**Total:** 235

## Subordinate Units

- 15. Panzer-Division
- 21. Panzer-Division
- Panzerkorps-Nachrichten-Abteilung 475

