# Western Desert Force

**Nation:** British
**Quarter:** 1940-Q2
**Organization Level:** corps

## Commander

Major-General Major-General Richard Nugent O'Connor

## Personnel

Total: 31000

---
*Generated automatically from TO&E data*
