# Deutsches Afrikakorps

**Nation:** German
**Quarter:** 1942q3
**Organization Level:** corps

## Commander

Generalleutnant Generalleutnant Walther Nehring

## Personnel

Total: 50500

---
*Generated automatically from TO&E data*
