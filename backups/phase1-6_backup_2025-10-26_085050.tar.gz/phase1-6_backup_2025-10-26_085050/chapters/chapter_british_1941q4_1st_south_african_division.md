# 1st South African Infantry Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Lieutenant-General Lt-Gen George Edwin Brink

## Personnel

Total: 15800

---
*Generated automatically from TO&E data*
