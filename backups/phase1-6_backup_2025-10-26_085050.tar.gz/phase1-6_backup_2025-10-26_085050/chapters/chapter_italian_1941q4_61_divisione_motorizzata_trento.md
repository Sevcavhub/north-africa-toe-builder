# 61ª Divisione Motorizzata "Trento"

**Nation:** Italian
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Major General (Generale di Divisione) Generale di Divisione Francesco La Ferla

## Personnel

Total: 10200

---
*Generated automatically from TO&E data*
