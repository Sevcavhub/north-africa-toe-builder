# 7th Armoured Division

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General William Henry Ewart Gott

## Personnel

Total: 14850

---
*Generated automatically from TO&E data*
