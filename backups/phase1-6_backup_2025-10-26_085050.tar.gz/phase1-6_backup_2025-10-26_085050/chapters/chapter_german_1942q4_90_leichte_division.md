# 90. leichte Afrika-Division

**Nation:** German
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Generalmajor Generalmajor Theodor Graf von Sponeck

## Personnel

Total: 10500

---
*Generated automatically from TO&E data*
