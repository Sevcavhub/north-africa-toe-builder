# 39ª Divisione di Fanteria "Bologna"

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Mario Marghinotti

## Personnel

Total: 11150

---
*Generated automatically from TO&E data*
