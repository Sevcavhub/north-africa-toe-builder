# 17ª Divisione di fanteria "Pavia"

**Nation:** Italian
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Generale di Divisione Pietro ZAGLIO (Apr 1-20) / Umberto MARCHESI (Apr 21-May 17) / Antonio FRANCESCHINI (May 18-Jun 30)

## Personnel

Total: 10864

---
*Generated automatically from TO&E data*
