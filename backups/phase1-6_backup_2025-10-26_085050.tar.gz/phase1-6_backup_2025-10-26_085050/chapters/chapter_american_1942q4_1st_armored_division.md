# 1st Armored Division

**Nation:** American
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Major General Orlando Ward

## Personnel

Total: 14620

---
*Generated automatically from TO&E data*
