# 5. leichte Division

**Nation:** German
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Generalmajor Generalmajor Johannes Streich

## Personnel

Total: 12000

---
*Generated automatically from TO&E data*
