# 17ª Divisione di Fanteria "Pavia"

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Generale di Brigata Antonio Franceschini

## Personnel

Total: 10850

---
*Generated automatically from TO&E data*
