# 133a Divisione Corazzata LITTORIO

**Nation:** Italian
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Gervasio Bitossi

## Personnel

Total: 7800

---
*Generated automatically from TO&E data*
