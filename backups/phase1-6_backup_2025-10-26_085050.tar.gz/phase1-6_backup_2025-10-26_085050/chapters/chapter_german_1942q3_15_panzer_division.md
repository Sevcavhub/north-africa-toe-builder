# 15. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Generalmajor Generalmajor Gustav von Vaerst

## Personnel

Total: 13450

---
*Generated automatically from TO&E data*
