# 21. Panzer-Division

**Nation:** German
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Generalmajor Johann von Ravenstein

## Personnel

Total: 12500

---
*Generated automatically from TO&E data*
