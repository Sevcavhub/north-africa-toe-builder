# 102. Divisione Motorizzata Trento

**Nation:** Italian
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Giorgio Masina

## Personnel

Total: 10850

---
*Generated automatically from TO&E data*
