# 10th Armoured Division

**Nation:** British
**Quarter:** 1942-Q4
**Organization Level:** division

## Commander

Major-General Major-General Alexander Hugh Gatehouse

## Personnel

Total: 14450

---
*Generated automatically from TO&E data*
