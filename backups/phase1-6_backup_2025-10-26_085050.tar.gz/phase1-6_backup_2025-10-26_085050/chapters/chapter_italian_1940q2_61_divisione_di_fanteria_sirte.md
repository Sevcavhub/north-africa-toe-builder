# 61ª Divisione di Fanteria "Sirte"

**Nation:** Italian
**Quarter:** 1940-Q2
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Vincenzo Della Mura

## Personnel

Total: 7350

---
*Generated automatically from TO&E data*
