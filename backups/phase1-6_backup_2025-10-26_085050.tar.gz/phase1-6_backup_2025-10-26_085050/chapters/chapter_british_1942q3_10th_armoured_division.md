# 10th Armoured Division

**Nation:** British
**Quarter:** 1942q3
**Organization Level:** division

## Commander

Major-General Alexander Hugh Gatehouse

## Personnel

Total: 14520

---
*Generated automatically from TO&E data*
