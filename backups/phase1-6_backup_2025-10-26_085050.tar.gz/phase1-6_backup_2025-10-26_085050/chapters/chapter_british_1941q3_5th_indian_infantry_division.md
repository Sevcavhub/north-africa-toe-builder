# 5th Indian Infantry Division

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General Ashton Gerard Oswald Mosley Mayne

## Personnel

Total: 15920

---
*Generated automatically from TO&E data*
