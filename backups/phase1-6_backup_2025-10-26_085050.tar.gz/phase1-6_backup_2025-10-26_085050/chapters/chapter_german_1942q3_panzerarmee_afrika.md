# Panzerarmee Afrika

**Nation:** German
**Quarter:** 1942-Q3
**Organization Level:** theater

## Commander

Generalfeldmarschall Generalfeldmarschall Erwin Rommel

## Personnel

Total: 96000

---
*Generated automatically from TO&E data*
