# 60ª Divisione di Fanteria 'Sabratha'

**Nation:** Italian
**Quarter:** 1940-Q3
**Organization Level:** division

## Command

**Commander:** Generale di Divisione Generale di Divisione Guido Della Bona

## Personnel

- **Total:** 12,850
- **Officers:** 642
- **NCOs:** 1,928
- **Enlisted:** 10,280

## Tanks

- **Total:** 0

## Artillery

**Total:** 36

## Vehicles

**Total:** 288

## Data Quality

- **Confidence:** 74%
- **Completeness:** 78%
