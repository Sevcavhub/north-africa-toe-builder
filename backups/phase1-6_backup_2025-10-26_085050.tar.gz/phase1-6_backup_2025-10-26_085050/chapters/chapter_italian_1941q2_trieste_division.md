# 101ª Divisione Motorizzata "Trieste"

**Nation:** Italian
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Lieutenant General Generale di Divisione Alessandro Piazzoni

---
*Generated from TO&E data*
