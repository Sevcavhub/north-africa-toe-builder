# 50th (Northumbrian) Infantry Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Major General Major General William Havelock Ramsden

## Personnel

Total: 15200

---
*Generated automatically from TO&E data*
