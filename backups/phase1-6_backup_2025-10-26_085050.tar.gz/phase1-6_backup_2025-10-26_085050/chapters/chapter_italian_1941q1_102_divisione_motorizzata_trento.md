# 102ª Divisione Motorizzata "Trento"

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Generale di Divisione Luigi Nuvoloni

## Personnel

Total: 10850

---
*Generated automatically from TO&E data*
