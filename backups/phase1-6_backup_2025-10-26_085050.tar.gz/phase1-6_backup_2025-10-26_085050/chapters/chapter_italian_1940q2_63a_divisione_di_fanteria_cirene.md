# 63a Divisione di Fanteria "Cirene"

**Nation:** Italian
**Quarter:** 1940-Q2
**Organization Level:** division

## Commander

Generale di Divisione Unknown (not documented)

## Personnel

Total: 12169

---
*Generated automatically from TO&E data*
