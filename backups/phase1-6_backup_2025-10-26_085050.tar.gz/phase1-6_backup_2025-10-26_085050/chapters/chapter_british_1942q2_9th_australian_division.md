# 9th Australian Division

**Nation:** British
**Quarter:** 1942-Q2
**Organization Level:** division

## Commander

Lieutenant-General Lieutenant-General Leslie James Morshead

## Personnel

Total: 16000

---
*Generated automatically from TO&E data*
