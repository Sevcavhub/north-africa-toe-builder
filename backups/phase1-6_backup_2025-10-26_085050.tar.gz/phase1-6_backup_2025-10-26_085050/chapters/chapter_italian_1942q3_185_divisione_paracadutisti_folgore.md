# 185ª Divisione Paracadutisti Folgore

**Nation:** Italian
**Quarter:** 1942-Q3
**Organization Level:** division

## Commander

Brigadier General Generale di Brigata Enrico Frattini

## Personnel

Total: 5200

---
*Generated automatically from TO&E data*
