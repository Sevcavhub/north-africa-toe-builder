# 21. Panzer-Division

**Nation:** German
**Quarter:** 1942-Q2
**Organization Level:** division

## Commander

Generalmajor Generalmajor Georg von Bismarck

## Personnel

Total: 13800

---
*Generated automatically from TO&E data*
