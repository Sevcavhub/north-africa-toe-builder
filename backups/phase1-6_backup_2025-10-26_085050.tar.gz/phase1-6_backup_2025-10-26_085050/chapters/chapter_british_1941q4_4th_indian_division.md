# 4th Indian Infantry Division

**Nation:** British
**Quarter:** 1941-Q4
**Organization Level:** division

## Command

**Commander:** Major-General Major-General Frank Walter Messervy

## Personnel

- **Total:** 17,800

## Tanks

- **Total:** 0

## Artillery

**Total:** 120

