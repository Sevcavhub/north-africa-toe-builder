# 133rd LITTORIO Armored Division

**Nation:** Italian
**Quarter:** 1942-Q2
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Gervasio Bitossi

## Personnel

Total: 7400

---
*Generated automatically from TO&E data*
