# Deutsches Afrikakorps

**Nation:** German
**Quarter:** 1941-Q4
**Organization Level:** corps

## Commander

Generalleutnant Ludwig Crüwell

## Personnel

Total: 45800

---
*Generated automatically from TO&E data*
