# 21. Panzer-Division

**Nation:** German
**Quarter:** 1941-Q4
**Organization Level:** division

## Commander

Generalleutnant Generalleutnant Johann von Ravenstein

## Personnel

Total: 12500

---
*Generated automatically from TO&E data*
