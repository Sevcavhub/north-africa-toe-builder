# 8th Army

**Nation:** British
**Quarter:** 1941q4
**Organization Level:** theater

## Commander

Lieutenant-General Lieutenant-General Sir Alan Gordon Cunningham (18 Nov - 26 Nov 1941), then Lieutenant-General Neil Methuen Ritchie (26 Nov 1941 - )

## Personnel

Total: 118000

---
*Generated automatically from TO&E data*
