# II Corps

**Nation:** American
**Quarter:** 1943-Q1
**Organization Level:** corps

## Commander

Major General Major General Lloyd Fredendall

## Personnel

Total: 95000

---
*Generated automatically from TO&E data*
