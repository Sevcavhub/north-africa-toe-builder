# 55ª Divisione motorizzata "Trento"

**Nation:** Italian
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Major General (Generale di Divisione) Generale di Divisione Luigi Nuvoloni

## Personnel

Total: 9500

---
*Generated automatically from TO&E data*
