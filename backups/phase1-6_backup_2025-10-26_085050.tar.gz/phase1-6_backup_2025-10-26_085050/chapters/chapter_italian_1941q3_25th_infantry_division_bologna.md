# 25th Infantry Division "Bologna"

**Nation:** Italian
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major General Generale di Divisione Alessandro Gloria

## Personnel

Total: 11500

---
*Generated automatically from TO&E data*
