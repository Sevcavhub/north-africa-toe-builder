# 70th Infantry Division

**Nation:** British
**Quarter:** 1941-Q3
**Organization Level:** division

## Commander

Major-General Ronald MacKenzie Scobie

## Personnel

Total: 28000

---
*Generated automatically from TO&E data*
