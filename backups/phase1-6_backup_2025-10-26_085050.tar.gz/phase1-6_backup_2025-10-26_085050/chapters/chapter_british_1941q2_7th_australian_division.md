# 7th Australian Division

**Nation:** British
**Quarter:** 1941-Q2
**Organization Level:** division

## Commander

Major-General Major-General John Lavarack (until 18 June 1941), then Major-General Arthur Allen

## Personnel

Total: 17800

## Artillery

Total: 126 pieces

---
*Generated from TO&E data*
