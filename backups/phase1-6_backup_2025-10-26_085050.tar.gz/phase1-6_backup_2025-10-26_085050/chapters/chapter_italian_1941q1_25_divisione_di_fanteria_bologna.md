# 25ª Divisione di Fanteria 'Bologna'

**Nation:** Italian
**Quarter:** 1941-Q1
**Organization Level:** division

## Commander

Generale di Divisione Generale di Divisione Roberto Lerici

## Personnel

Total: 10125

---
*Generated automatically from TO&E data*
